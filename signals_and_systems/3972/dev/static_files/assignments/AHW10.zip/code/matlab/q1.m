[y, Fs] = audioread('mic.wav');
y = y(:,1); % changing stereo sound to mono
f = fft(y);
m = abs(f);
p = angle(f);

% mines phase
mp = -1 * p;
f = m .* exp(j*mp);
my = ifft(f);
audiowrite('mt.wav', my, Fs);

% zero phase
mp = 0 * p;
f = m .* exp(j*mp);
my = ifft(f);
audiowrite('zt.wav', my, Fs);

% phase + pi/2
mp = p
for i = linspace(0, length(p) - 1, length(p))
    mp(i + 1) = mp(i + 1) + i * (pi / 2);
end
f = m .* exp(j*mp);
my = ifft(f);
audiowrite('p2pt.wav', my, Fs);

% phase + pi
mp = p
for i = linspace(0, length(p) - 1, length(p))
    mp(i + 1) = mp(i + 1) + i * (pi - 0.1);
end
f = m .* exp(j*mp);
my = ifft(f);
audiowrite('ppt.wav', my, Fs);

% phase - pi / 2
mp = p
for i = linspace(0, length(p) - 1, length(p))
    mp(i + 1) = mp(i + 1) - i * (pi / 2);
end
f = m .* exp(j*mp);
my = ifft(f);
audiowrite('p2mt.wav', my, Fs);

% double abs
f = 2 * m .* exp(j*p);
my = ifft(f);
audiowrite('da.wav', my, Fs);

% ten *  abs
f = 10 * m .* exp(j*p);
my = ifft(f);
audiowrite('ten_a.wav', my, Fs);

% abs = miangin
mi = sum(m) / length(m);
f = mi .* exp(j*p);
my = ifft(f);
audiowrite('mia.wav', my, Fs);

% subs
[y1, Fs1] = audioread('trac.wav');
y1 = y1(:,1); % changing stereo sound to mono
f1 = fft(y1);
m1 = abs(f1);
p1 = angle(f1);

% make same shape
if length(m) < length(p1)
    f = m .* exp(j*p1(1:length(m)));
else
    f = m(1:length(p1)) .* exp(j * p1);
end
my = ifft(f);
audiowrite('a_m_p_t.wav', my, Fs); % abs from mic and phase from trac

% make same shape
if length(m1) < length(p)
    f = m1 .* exp(j * p(1:length(m1)));
else
    f = m1(1:length(p)) .* exp(j * p);
end
my = ifft(f);
audiowrite('a_t_p_m.wav', my, Fs); % abs from trac and phase from mic
% Be careful that saved file is in bin directory in matlab path where installed.