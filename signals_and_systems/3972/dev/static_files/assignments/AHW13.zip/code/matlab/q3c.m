[data, fs] = audioread('261.wav');
disp(fs); % rate of sampling
% getthing 30 ms of non-zero sound
th_data = ceil(ceil(length(data) / fs) * 0.03 * length(data));
f_data = 0;
for i = linspace(1, length(data), length(data))
    if data(i) ~= 0
        f_data = i;
        break;
    end
end

deci = decimate(data, 5);
filename = 'deci.wav'; 
audiowrite(filename, deci, (fs/5));
% getthing 30 ms of non-zero sound
th_deci = ceil(ceil(length(deci) * 5 / fs) * 0.03 * length(deci));
f_deci = 0;
for i = linspace(1, length(deci), length(deci))
    if deci(i) ~= 0
        f_deci = i;
        break;
    end
end

resa = downsample(data, 5);
filename = 'resa.wav'; 
audiowrite(filename, resa, (fs/5));
% getthing 30 ms of non-zero sound
th_resa = ceil(ceil(length(resa) * 5 / fs) * 0.03 * length(resa));
f_resa = 0;
for i = linspace(1, length(resa), length(resa))
    if resa(i) ~= 0
        f_resa = i;
        break;
    end
end

% plotting
subplot(3, 1, 1);
plot(linspace(0, th_data - 1, th_data), data(f_data:f_data + th_data - 1));
title('data');
subplot(3, 1, 2);
plot(linspace(0, th_deci - 1, th_deci), data(f_deci:f_deci + th_deci - 1));
title('decimate');
subplot(3, 1, 3);
plot(linspace(0, th_resa - 1, th_resa), data(f_resa:f_resa + th_resa - 1));
title('downsample');