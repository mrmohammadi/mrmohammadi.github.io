t = input('enter type of filter(1 for low pass, 2 for high pass): ');
wc = input('enter w cut off (a fraction of the sampling rate (in (0, 0.5))): ');
a = input('enter delta for error (in (0, 1)): ');
dw = input('enter delta w for pass frequency (a fraction of the sampling rate (in (0, 0.5))): ');
fname = input('enter result filename: ', 's');

alpha = 20 * log10(a);
if alpha > -21
    m = ceil((4 * pi) / (2 * pi * dw));
    if mod(m, 2) == 0
        m = m + 1;
    end
    w = transpose(rectwin(m));
elseif alpha > -25
    m = ceil((8 * pi) / (2 * pi * dw)) + 1;
    if mod(m, 2) == 0
        m = m + 1;
    end
    w = transpose(bartlett(m));
elseif alpha > -44
    m = ceil((8 * pi) / (2 * pi * dw)) + 1;
    if mod(m, 2) == 0
        m = m + 1;
    end
    w = transpose(hann(m));
elseif alpha > -53
    m = ceil((8 * pi) / (2 * pi * dw)) + 1;
    if mod(m, 2) == 0
        m = m + 1;
    end
    w = transpose(hamming(m));
else
    m = ceil((12 * pi) / (2 * pi * dw)) + 1;
    if mod(m, 2) == 0
        m = m + 1;
    end
    w = transpose(blackman(m));
end
n = linspace(0, m - 1, m);
f = sinc(2 * wc * (n - (m - 1) / 2.));
fw = f .* w;
fw = fw / sum(fw);
if t == 2
    fw = -fw;
    fw(ceil((m - 1) / 2)) = fw(ceil((m - 1) / 2)) + 1;
end
[data, fs] = audioread('voice.wav');
d = conv(data, fw, 'same');
audiowrite(fname, d, fs);