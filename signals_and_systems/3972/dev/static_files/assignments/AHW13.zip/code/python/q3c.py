#!/usr/bin/env python3
from scipy.io import wavfile as wav
from scipy.signal import decimate
import matplotlib.pyplot as plt
import numpy as np

fs, data = wav.read('261.wav')
print("fs(Hz): ", fs) # rate of sampling
# getthing 30 ms of non-zero sound
th_data = int(np.ceil(np.ceil(len(data) / fs) * 0.03 * len(data)))
for i in range(len(data)):
    if data[i] != 0:
        f_data = i
        break

deci = decimate(data, 5)
wav.write("deci.wav", int(fs / 5), deci.astype(data.dtype))
# getthing 30 ms of non-zero sound
th_deci = int(np.ceil(np.ceil(len(deci) * 5 / fs) * 0.03 * len(deci)))
for i in range(len(deci)):
    if deci.astype(data.dtype)[i] != 0:
        f_deci = i
        break

# i dont find like downsample in matlab so i write it selfly.
resa = np.array(data[::5])
wav.write("resa.wav", int(fs / 5), resa.astype(data.dtype))
# getthing 30 ms of non-zero sound
th_resa = int(np.ceil(np.ceil(len(resa) * 5 / fs) * 0.03 * len(resa)))
for i in range(len(resa)):
    if resa.astype(data.dtype)[i] != 0:
        f_resa = i
        break

#plotting
fig, axs = plt.subplots(3, 1, constrained_layout=True)
axs[0].plot(np.array(range(th_data)), data[f_data:f_data + th_data])
axs[0].set_title('data')

axs[1].plot(np.array(range(th_deci)), deci.astype(data.dtype)[f_deci:f_deci + th_deci])
axs[1].set_title('decimate')

axs[2].plot(np.array(range(th_resa)), resa.astype(data.dtype)[f_resa:f_resa + th_resa])
axs[2].set_title('downsample')
plt.show()
