#!/usr/bin/env python3
import numpy as np
from scipy import signal
from scipy.io import wavfile as wav

t = int(input("enter type of filter(1 for low pass, 2 for high pass): "))
wc = float(input("enter w cut off (a fraction of the sampling rate (in (0, 0.5))): "))
a = float(input("enter delta for error (in (0, 1)): "))
dw = float(input("enter delta w for pass frequency (a fraction of the sampling rate (in (0, 0.5))): "))
fname = input("enter result filename: ")

alpha = 20 * np.log10(a)
if alpha > -21:
    m = int(np.ceil((4 * np.pi) / (2 * np.pi * dw)))
    if m % 2 == 0:
        m = m + 1
    w = signal.boxcar(m)
elif alpha > -25:
    m = int(np.ceil((8 * np.pi) / (2 * np.pi * dw))) + 1
    if m % 2 == 0:
        m = m + 1
    w = signal.bartlett(m)
elif alpha > -44:
    m = int(np.ceil((8 * np.pi) / (2 * np.pi * dw))) + 1
    if m % 2 == 0:
        m = m + 1
    w = signal.hann(m)
elif alpha > -53:
    m = int(np.ceil((8 * np.pi) / (2 * np.pi * dw))) + 1
    if m % 2 == 0:
        m = m + 1
    w = signal.hamming(m)
else:
    m = int(np.ceil((12 * np.pi) / (2 * np.pi * dw))) + 1;
    if m % 2 == 0:
        m = m + 1
    w = signal.blackman(m)

n = np.arange(m)
f = np.sinc(2 * wc * (n - (m - 1) / 2.))
fw = f * w
fw = fw / np.sum(fw)
if t == 2:
    fw = -fw
    fw[int((m - 1) / 2)] += 1
fs, data = wav.read('voice.wav')
d = np.convolve(data, fw, 'same')
wav.write(fname + ".wav", fs, d.astype(data.dtype))
