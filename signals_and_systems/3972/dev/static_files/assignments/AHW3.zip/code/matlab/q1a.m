n = linspace(-50, 50);
x = cos(6*n/7);
stem(n, x), hold on;
plot(n, x);