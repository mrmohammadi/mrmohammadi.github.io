t = linspace(-1, 1);
x = cos(2 * pi * t) + j * sin(pi * t);
stem(t, x), hold on;
plot(t, x);