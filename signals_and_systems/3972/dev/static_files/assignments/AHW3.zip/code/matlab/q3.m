f_x = input('enter first range for x: ');
l_x = input('enter last range for x: ');
n_x = linspace(f_x, l_x, (l_x - f_x) + 1);
x = [];
for i = n_x
    e = input(sprintf('enter x[%d]: ', i));
    x = [x e];
end
f_h = input('enter first range for h: ');
l_h = input('enter last range for h: ');
n_h = linspace(f_h, l_h, (l_h - f_h) + 1);
h = [];
for i = n_h
    e = input(sprintf('enter h[%d]: ', i));
    h = [h e];
end
y = conv(x, h);
subplot(3, 1, 1);
stem(n_x, x);
title('x[n]');
subplot(3, 1, 2);
stem(n_h, h);
title('h[n]');
subplot(3, 1, 3);
n_y = linspace(max(f_x, f_h), max(f_x, f_h) + length(y) - 1, length(y));
stem(n_y, y);
title('x[n]*h[n]');