m = input('enter m: ');
range = input('enter range: ');
f_x = -1 * range;
l_x = range;
n = linspace(f_x, l_x, (l_x - f_x) + 1);
x = sin(2 * pi * 0.043 * n) + sin(2 * pi * 0.031 * n);
f_d = ceil(f_x / m);
l_d = floor(l_x / m);
n_d = linspace(f_d, l_d, (l_d - f_d) + 1);
x_d = n_d;
for i = n_d
    x_d(i + l_d + 1) = x((m * i) + l_x + 1);
end
subplot(2, 1, 1);
stem(n, x);
title('x[n]');
subplot(2, 1, 2);
stem(n_d, x_d);
title('x[m*n]');
