m = input('enter m: ');
range = input('enter range: ');
f_x = -1 * range;
l_x = range;
n = linspace(f_x, l_x, (l_x - f_x) + 1);
x = sin(2 * pi * 0.043 * n) + sin(2 * pi * 0.031 * n);
f_d = m * f_x;
l_d = m * l_x;
n_d = linspace(f_d, l_d, (l_d - f_d) + 1);
x_d = n_d;
for i = n_d
    if i < 0
        ind = ceil(i / m);
    else
        ind = floor(i / m);
    end
    if i / m == ind
        x_d(i + l_d + 1) = x(ind + l_x + 1);
    else
        x_d(i + l_d + 1) = 0;
    end
end
subplot(2, 1, 1);
stem(n, x);
title('x[n]');
subplot(2, 1, 2);
stem(n_d, x_d);
title('x[n/m]');
