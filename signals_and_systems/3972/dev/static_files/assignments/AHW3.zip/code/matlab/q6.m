n_x = 0:15;
n_y = 0:30;
% u[n]
ustep0 = zeros(size(n_x));
ustep0(find(n_x >= 0)) = 1;
% u[n - 12]
ustep12 = zeros(size(n_x));
ustep12(find(n_x >= 12)) = 1;
% x[n]
x = ustep0 - ustep12;
% r[n]
uramp0 = zeros(size(n_y));
index = find(n_y > 0);
uramp0(index) = n_y(index) - 0;
% r[n - 4]
uramp4 = zeros(size(n_y));
index = find(n_y > 4);
uramp4(index) = n_y(index) - 4;
% r[n - 12]
uramp12 = zeros(size(n_y));
index = find(n_y > 12);
uramp12(index) = n_y(index) - 12;
% r[n - 16]
uramp16 = zeros(size(n_y));
index = find(n_y > 16);
uramp16(index) = n_y(index) - 16;
% y[n]
y = uramp0 - uramp4 - uramp12 + uramp16;
d = deconv(y, x);
n_d = n_x;
subplot(3, 1, 1);
stem(n_x, x);
title('x[n]');
subplot(3, 1, 2);
stem(n_y, y);
title('y[n]');
subplot(3, 1, 3);
stem(n_d, d);
title('d[n]');