#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt

n = np.linspace(-50, 50)
x = np.cos(6*n/7)
plt.stem(n, x)
plt.plot(n, x)
plt.show()

