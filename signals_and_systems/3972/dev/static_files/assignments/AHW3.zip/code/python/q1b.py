#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(-1, 1)
x = np.cos(2 * np.pi * t) + np.complex(0, 1) * np.sin(np.pi * t)
plt.stem(t, x)
plt.plot(t, x)
plt.show()
