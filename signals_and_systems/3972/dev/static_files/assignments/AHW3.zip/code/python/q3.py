#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt

f_x = int(input('enter first range for x: '))
l_x = int(input('enter last range for x: '))
n_x = np.linspace(f_x, l_x, (l_x - f_x) + 1)
x = []
for i in n_x:
    e = float(input('enter x[' + str(int(i)) + ']: '))
    x.append(e)
x = np.array(x)
f_h = int(input('enter first range for h: '))
l_h = int(input('enter last range for h: '))
n_h = np.linspace(f_h, l_h, (l_h - f_h) + 1)
h = []
for i in n_h:
    e = float(input('enter h[' + str(int(i)) + ']: '))
    h.append(e)
h = np.array(h)
y = np.convolve(x, h)
fig, axs = plt.subplots(3, 1, constrained_layout=True)
axs[0].stem(n_x, x)
axs[0].set_title('x[n]')
axs[1].stem(n_h, h)
axs[1].set_title('h[n]')
n_y = np.linspace(max(f_x, f_h), max(f_x, f_h) + len(y) - 1, len(y))
axs[2].stem(n_y, y)
axs[2].set_title('x[n]*h[n]')
plt.show()
