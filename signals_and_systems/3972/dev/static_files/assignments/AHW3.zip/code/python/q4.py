#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt

m = int(input('enter m: '))
r = int(input('enter range: '))
f_x = -1 * r
l_x = r
n = np.linspace(f_x, l_x, (l_x - f_x) + 1)
x = np.sin(2 * np.pi * 0.043 * n) + np.sin(2 * np.pi * 0.031 * n)
f_d = np.ceil(f_x / m)
l_d = np.floor(l_x / m)
n_d = np.linspace(f_d, l_d, (l_d - f_d) + 1)
x_d = np.copy(n_d)
for i in n_d:
    x_d[int(i + l_d)] = x[int((m * i) + l_x)]
fig, axs = plt.subplots(2, 1, constrained_layout=True)
axs[0].stem(n, x)
axs[0].set_title('x[n]')
axs[1].stem(n_d, x_d)
axs[1].set_title('x[m*n]')
plt.show()
