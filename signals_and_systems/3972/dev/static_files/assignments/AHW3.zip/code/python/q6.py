#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import deconvolve

n_x = np.arange(16)
n_y = np.arange(31)
# u[n]
ustep0 = np.zeros(len(n_x))
for i in n_x:
    if i >= 0:
        ustep0[int(i)] = 1
# u[n - 12]
ustep12 = np.zeros(len(n_x))
for i in n_x:
    if i >= 12:
        ustep12[int(i)] = 1
# x[n]
x = ustep0 - ustep12
# r[n]
uramp0 = np.zeros(len(n_y))
index = np.where(n_y > 0)
for i in index[0]:
    uramp0[int(i)] = n_y[int(i)] - 0
# r[n - 4]
uramp4 = np.zeros(len(n_y))
index = np.where(n_y > 4)
for i in index[0]:
    uramp4[int(i)] = n_y[int(i)] - 4
# r[n - 12]
uramp12 = np.zeros(len(n_y))
index = np.where(n_y > 12)
for i in index[0]:
    uramp12[int(i)] = n_y[int(i)] - 12
# r[n - 16]
uramp16 = np.zeros(len(n_y))
index = np.where(n_y > 16)
for i in index[0]:
    uramp16[int(i)] = n_y[int(i)] - 16
# y[n]
y = uramp0 - uramp4 - uramp12 + uramp16;
d = deconvolve(y, x)
n_d = np.copy(n_x)
fig, axs = plt.subplots(3, 1, constrained_layout=True)
axs[0].stem(n_x, x)
axs[0].set_title('x[n]')
axs[1].stem(n_y, y)
axs[1].set_title('y[n]')
axs[2].stem(n_d, d)
axs[2].set_title('d[n]')
plt.show()
