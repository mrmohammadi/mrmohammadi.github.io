x = randn(1, randi([5 10], 1, 1));
n_x = linspace(0, length(x) - 1, length(x));
h = [];
l = randi([2 5], 1, 1);
v = rand();
for i = 1:l
    h = [h v];
end
n_h = linspace(0, l - 1, l);
y = conv(x, h);
n_y = linspace(0, length(y) - 1, length(y));
subplot(3, 1, 1);
stem(n_x, x);
title('x[n]');
subplot(3, 1, 2);
stem(n_h, h);
title('h[n]');
subplot(3, 1, 3);
stem(n_y, y);
title('y[n]');