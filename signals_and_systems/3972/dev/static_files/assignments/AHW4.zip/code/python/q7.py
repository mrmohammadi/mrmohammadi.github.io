#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt

x = np.random.randn(1, np.random.randint(5, 10))[0]
n_x = np.linspace(0, len(x) - 1, len(x))
h = []
l = np.random.randint(2, 5)
v = np.random.rand()
for i in range(l):
    h.append(v)
h = np.array(h)
n_h = np.linspace(0, l - 1, l)
y = np.convolve(x, h)
n_y = np.linspace(0, len(y) - 1, len(y))
fig, axs = plt.subplots(3, 1, constrained_layout=True)
axs[0].stem(n_x, x)
axs[0].set_title('x[n]')
axs[1].stem(n_h, h)
axs[1].set_title('h[n]')
axs[2].stem(n_y, y)
axs[2].set_title('y[n]')
plt.show()
