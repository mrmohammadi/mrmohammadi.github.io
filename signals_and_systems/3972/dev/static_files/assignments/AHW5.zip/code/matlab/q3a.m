l = 3;
scale = 100;
N = 2*l;
k1 = linspace(-l, -0.01, l*scale);
k2 = linspace(0.01, l, l*scale);
n_a = [k1 0 k2];
a1 = N*2*1i*sin(k1*pi/6).*sin(k1*pi/2)./k1*pi;
a2 = N*2*1i*sin(k2*pi/6).*sin(k2*pi/2)./k2*pi;
a = [a1 0 a2];
x = [];
for i = n_a
    if i < -2 || (-1 < i && i < 1) || i > 2
        x = [x 0];
    elseif -2 <= i && i <= -1
        x = [x 1];
    else
        x = [x -1];
    end
end
subplot(6, 1, 1);
plot(n_a, x);
title('x(t)');
% m = 1
m = 1;
res = 0;
xm = [];
for n = n_a
    for k = linspace(-m*scale, m*scale, 2 * m * scale + 1)
        res = res + a(mod(k, length(a)) + 1) * exp(1i*2*pi*k/scale*n/N);
        %res = res + a(mod(k, length(a)) + 1) * exp(1i*2*pi*2*pi*n/N);
    end
    res = res / (2 * m * scale * 10 + 1);
    xm = [xm res];
end
subplot(6, 1, 2);
plot(n_a, xm);
title('m = 1');
% m = 2
m = 2;
res = 0;
xm = [];
for n = n_a
    for k = linspace(-m*scale, m*scale, 2 * m * scale + 1)
        res = res + a(mod(k, length(a)) + 1) * exp(1i*2*pi*k/scale*n/N);
        %res = res + a(mod(k, length(a)) + 1) * exp(1i*2*pi*2*pi*n/N);
    end
    res = res / (2 * m * scale * 10 + 1);
    xm = [xm res];
end
subplot(6, 1, 3);
plot(n_a, xm);
title('m = 2');
% m = 5
m = 5;
res = 0;
xm = [];
for n = n_a
    for k = linspace(-m*scale, m*scale, 2 * m * scale + 1)
        res = res + a(mod(k, length(a)) + 1) * exp(1i*2*pi*k/scale*n/N);
        %res = res + a(mod(k, length(a)) + 1) * exp(1i*2*pi*2*pi*n/N);
    end
    res = res / (2 * m * scale * 10 + 1);
    xm = [xm res];
end
subplot(6, 1, 4);
plot(n_a, xm);
title('m = 5');
% m = 10
m = 10;
res = 0;
xm = [];
for n = n_a
    for k = linspace(-m*scale, m*scale, 2 * m * scale + 1)
        res = res + a(mod(k, length(a)) + 1) * exp(1i*2*pi*k/scale*n/N);
        %res = res + a(mod(k, length(a)) + 1) * exp(1i*2*pi*2*pi*n/N);
    end
    res = res / (2 * m * scale * 10 + 1);
    xm = [xm res];
end
subplot(6, 1, 5);
plot(n_a, xm);
title('m = 10');
% m = 50
m = 50;
res = 0;
xm = [];
for n = n_a
    for k = linspace(-m*scale, m*scale, 2 * m * scale + 1)
        res = res + a(mod(k, length(a)) + 1) * exp(1i*2*pi*k/scale*n/N);
        %res = res + a(mod(k, length(a)) + 1) * exp(1i*2*pi*2*pi*n/N);
    end
    res = res / (2 * m * scale * 10 + 1);
    xm = [xm res];
end
subplot(6, 1, 6);
plot(n_a, xm);
title('m = 50');