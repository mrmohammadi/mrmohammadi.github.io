N = input('Enter N: ');
w0 = 2 * pi / N;
x = [];
n_x = linspace(0, N - 1, N);
x = [];
for i = n_x
    e = input(sprintf('Enter x[%d]: ', i));
    x = [x e];
end
a = [];
for k = n_x
    res = 0;
    for n = n_x
        res = res +(x(n + 1) * exp((-1) * 1i * k * w0 * n));
    end
    %res = res / N;
    a = [a res];
end
subplot(6, 1, 1);
stem(n_x, x);
title('x[n]');
% m = 1
m = 1;
xm = [];
for n = n_x
    res = 0;
    for k = -m:m
        res = res + a(mod(k, length(a)) + 1) * exp(1i*2*pi*k*n/N);
        %res = res + a(mod(k, length(a)) + 1) * exp(1i*2*pi*2*pi*n/N);
    end
    res = res / (2 * m + 1);
    xm = [xm res];
end
subplot(6, 1, 2);
stem(n_x, xm);
title('m = 1');
% m = 2
m = 2;
xm = [];
for n = n_x
    res = 0;
    for k = -m:m
        res = res + a(mod(k, length(a)) + 1) * exp(1i*2*pi*k*n/N);
        %res = res + a(mod(k, length(a)) + 1) * exp(1i*2*pi*2*pi*n/N);
    end
    res = res / (2 * m + 1);
    xm = [xm res];
end
subplot(6, 1, 3);
stem(n_x, xm);
title('m = 2');
% m = 5
m = 5;
xm = [];
for n = n_x
    res = 0;
    for k = -m:m
        res = res + a(mod(k, length(a)) + 1) * exp(1i*2*pi*k*n/N);
        %res = res + a(mod(k, length(a)) + 1) * exp(1i*2*pi*2*pi*n/N);
    end
    res = res / (2 * m + 1);
    xm = [xm res];
end
subplot(6, 1, 4);
stem(n_x, xm);
title('m = 5');
% m = 10
m = 10;
xm = [];
for n = n_x
    res = 0;
    for k = -m:m
        res = res + a(mod(k, length(a)) + 1) * exp(1i*2*pi*k*n/N);
        %res = res + a(mod(k, length(a)) + 1) * exp(1i*2*pi*2*pi*n/N);
    end
    res = res / (2 * m + 1);
    xm = [xm res];
end
subplot(6, 1, 5);
stem(n_x, xm);
title('m = 5');
% m = 50
m = 50;
xm = [];
for n = n_x
    res = 0;
    for k = -m:m
        res = res + a(mod(k, length(a)) + 1) * exp(1i*2*pi*k*n/N);
        %res = res + a(mod(k, length(a)) + 1) * exp(1i*2*pi*2*pi*n/N);
    end
    res = res / (2 * m + 1);
    xm = [xm res];
end
subplot(6, 1, 6);
stem(n_x, xm);
title('m = 50');