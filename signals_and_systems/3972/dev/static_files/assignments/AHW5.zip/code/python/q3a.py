#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt

j = np.complex(0, 1)
pi = np.pi

l = 3
scale = 100
N = 2*l
k1 = np.linspace(-l, -0.01, l*scale)
k2 = np.linspace(0.01, l, l*scale)
n_a = np.array(list(k1) + [0] + list(k2))
a1 = N * 2 * j * np.sin(k1 * pi / 6) * np.sin(k1 * pi / 2) / (k1 * pi)
a2 = N * 2 * j * np.sin(k2 * pi / 6) * np.sin(k2 * pi / 2) / (k2 * pi)
a = np.array(list(a1) + [0] + list(a2))
x = []
for i in n_a:
    if i < -2 or -1 < i < 1 or i > 2:
        x.append(0)
    elif -2 <= i <= -1:
        x.append(1)
    else:
        x.append(-1)
fig, axs = plt.subplots(6, 1, constrained_layout=True)
axs[0].plot(n_a, x)
axs[0].set_title('x(t)')

M = [1, 2, 5, 10, 50]
for m in M:
    xm = []
    for n in n_a:
        res = 0
        for k in range((-1) * m, m + 1):
            res += a[int(k % len(a))] * np.exp(j * k * 2 * pi * n / N)
            #res += a[int(k % len(a))] * npexp(j * 2 * pi * 2 * pi * n / N)
        res /= (2 * m + 1)
        xm.append(res)
    axs[M.index(m) + 1].plot(n_a, xm)
    axs[M.index(m) + 1].set_title('m = ' + str(m))
plt.show()
