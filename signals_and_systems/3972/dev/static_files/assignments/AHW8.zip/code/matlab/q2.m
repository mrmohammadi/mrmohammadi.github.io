N = input('Enter N: ');
w0 = 2 * pi / N;
x = [];
n_x = linspace(0, N - 1, N);
x = [];
for i = n_x
    e = input(sprintf('Enter x[%d]: ', i));
    x = [x e];
end
a = [];
for k = n_x
    res = 0;
    for n = n_x
        res = res +(x(n + 1) * exp((-1) * 1i * k * w0 * n));
    end
    res = res / N;
    a = [a res];
end
disp(a);