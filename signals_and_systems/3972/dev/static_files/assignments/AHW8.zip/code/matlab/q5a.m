x = [0 1 2 3 4 5 4 3 2 1 0];
n = 10000;
y = fft(x, n);
% or
% n = 10000;
% x = [0 1 2 3 4 5 4 3 2 1 0 zeros([1, n-11])];
% y = fft(x);
subplot(4, 1, 1);
stem(linspace(0, 2 * pi, n), y);
title('x(e^j^w)');
subplot(4, 1, 2);
stem(linspace(0, 2 * pi, n), abs(y));
title('|x(e^j^w)|');
subplot(4, 1, 3);
stem(linspace(0, 2 * pi, n), angle(y));
title('angle(x(e^j^w))');
subplot(4, 1, 4);
stem(0:length(x) - 1, x);
title('x[n]');
