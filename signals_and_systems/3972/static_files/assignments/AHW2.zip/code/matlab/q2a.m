n = linspace(-50, 50);
x = exp(j*3*n/7);
stem(n, x), hold on;
plot(n, x);