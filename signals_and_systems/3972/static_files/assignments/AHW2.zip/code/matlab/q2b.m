t = linspace(-0.75, 0.75);
x = abs(sin(2*pi*t/3)) + cos(4*pi*t/3);
plot(t, x), hold on;
stem(t, x);