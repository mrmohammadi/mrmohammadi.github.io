n = linspace(-3, 3, 7);
t = linspace(-3, 3);
xs = exp(j * pi * n / 3) + exp(j * pi * 4 * n / 3);
xp = exp(j * pi * t / 3) + exp(j * pi * 4 * t / 3);
plot(t, xp), hold on;
stem(n, xs);