% cos(9*t)
t = linspace(-2*pi/18, 2*pi/18);
x = cos(9*t);
subplot(3, 1, 1);
plot(t, x), hold on;
stem(t, x);
title('cos(9*t)');
% sin(2*pi*t)
t = linspace(-0.5, 0.5);
x = sin(2 * pi * t);
subplot(3, 1, 2);
plot(t, x), hold on;
stem(t, x);
title('sin(2*pi*t)');
% cos(9*t) + sin(2*pi*t)
t = linspace(-5, 5);
x = cos(9*t) + sin(2 * pi * t);
subplot(3, 1, 3);
plot(t, x), hold on;
stem(t, x);
title('cos(9*t) + sin(2*pi*t)');