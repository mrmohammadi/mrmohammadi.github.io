range = input('enter range: ');
n = linspace(-range, range, 2 * range + 1);
x = [];
for i = n
    e = input(sprintf('enter x[%d]: ', i));
    x = [x e];
end
xr = x(end: -1: 1);
xe = (x + xr) / 2;
xo = (x - xr) / 2;
subplot(3, 1, 1);
stem(n, x);
title('x[n]');
subplot(3, 1, 2);
stem(n, xe);
title('xe[n]');
subplot(3, 1, 3);
stem(n, xo);
title('xo[n]');