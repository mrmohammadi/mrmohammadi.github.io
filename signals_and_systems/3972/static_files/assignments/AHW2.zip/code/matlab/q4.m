t = linspace(-5, 5);
% cos(w0*t+theta)
w0 = pi/3;
theta = pi/4;
x = cos(w0*t+theta);
subplot(3, 2, 1);
plot(t, x);
title('cos(w0*t+theta)');
% abs(c) * exp(r * t)
c = 2;
r = 1;
x = abs(c) * exp(r * t);
subplot(3, 2, 2);
plot(t, x);
title('abs(c) * exp(r * t)');
% cos(w0*t+theta)*abs(c) .* exp(r * t)
x = cos(w0*t+theta)*abs(c) .* exp(r * t);
subplot(3, 2, 3);
plot(t, x);
title('cos(w0*t+theta)*abs(c) .* exp(r * t)');

n = linspace(-5, 5, 11);
% cos(w0*n+theta)
w0 = pi/3;
theta = pi/4;
x = cos(w0*n+theta);
subplot(3, 2, 4);
stem(n, x);
title('cos(w0*n+theta)');
% abs(c) * exp(r * n)
c = 2;
r = 1;
x = abs(c) * exp(r * n);
subplot(3, 2, 5);
stem(n, x);
title('abs(c) * exp(r * n)');
% cos(w0*n+theta)*abs(c) .* exp(r * n)
x = cos(w0*n+theta)*abs(c) .* exp(r * n);
subplot(3, 2, 6);
stem(n, x);
title('cos(w0*n+theta)*abs(c) .* exp(r * n)');