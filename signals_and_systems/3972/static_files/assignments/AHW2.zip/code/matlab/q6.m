t = linspace(-5, 5);
x = 3 * sin(pi * t) + 3 * abs(cos(7 * t));
y = []
for i = x
    if i > 5
        y = [y 5];
    elseif i < 0
        y = [y 0];
    else
        y = [y i];
    end
end
subplot(2, 1, 1);
plot(t, x);
title('x(t)');
subplot(2, 1, 2);
plot(t, y);
title('y(t)');