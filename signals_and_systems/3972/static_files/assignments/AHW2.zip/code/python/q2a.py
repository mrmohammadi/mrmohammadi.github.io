#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt

j = np.complex(0, 1)
n = np.linspace(-50, 50)
x = np.exp(j*3*n/7)
plt.stem(n, x)
plt.plot(n, x)
plt.show()
