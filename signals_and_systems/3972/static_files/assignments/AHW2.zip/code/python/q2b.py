#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(-0.75, 0.75)
x = np.abs(np.sin(2*np.pi*t/3)) + np.cos(4*np.pi*t/3)
plt.stem(t, x)
plt.plot(t, x)
plt.show()
