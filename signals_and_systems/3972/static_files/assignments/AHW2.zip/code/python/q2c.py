#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt

pi = np.pi
j = np.complex(0, 1)
n = np.linspace(-3, 3, 7)
t = np.linspace(-3, 3)
xs = np.exp(j * pi * n / 3) + np.exp(j * pi * 4 * n / 3)
xp = np.exp(j * pi * t / 3) + np.exp(j * pi * 4 * t / 3)
plt.plot(t, xp)
plt.stem(n, xs)
plt.show()
