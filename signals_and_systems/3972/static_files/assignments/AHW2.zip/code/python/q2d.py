#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt

pi = np.pi

# cos(9*t)
t = np.linspace(-2*pi/18, 2*pi/18)
x = np.cos(9*t)
fig, axs = plt.subplots(3, 1, constrained_layout=True)
axs[0].plot(t, x)
axs[0].stem(t, x);
axs[0].set_title('cos(9*t)');
# sin(2*pi*t)
t = np.linspace(-0.5, 0.5)
x = np.sin(2 * pi * t)
axs[1].plot(t, x)
axs[1].stem(t, x)
axs[1].set_title('sin(2*pi*t)')
# cos(9*t) + sin(2*pi*t)
t = np.linspace(-5, 5)
x = np.cos(9*t) + np.sin(2 * pi * t)
axs[2].plot(t, x)
axs[2].stem(t, x)
axs[2].set_title('cos(9*t) + sin(2*pi*t)')
plt.show()
