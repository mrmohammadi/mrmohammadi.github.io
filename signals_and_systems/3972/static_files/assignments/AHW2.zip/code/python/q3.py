#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt

r = int(input('enter range: '))
n = np.linspace(-r, r, 2 * r + 1)
x = []
for i in n:
    e = int(input('enter x[' + str(int(i)) + ']: '))
    x.append(e)
xr = x[:: -1]
x = np.array(x)
xr = np.array(xr)
xe = (x + xr) / 2
xo = (x - xr) / 2
fig, axs = plt.subplots(3, 1, constrained_layout=True)
axs[0].stem(n, x)
axs[0].set_title('x[n]')
axs[1].stem(n, xe)
axs[1].set_title('xe[n]')
axs[2].stem(n, xo)
axs[2].set_title('xo[n]')
plt.show()
