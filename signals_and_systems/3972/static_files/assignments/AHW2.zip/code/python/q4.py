#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt

pi = np.pi
t = np.linspace(-5, 5)
# cos(w0*t+theta)
w0 = pi/3
theta = pi/4
x = np.cos(w0*t+theta)
fig, axs = plt.subplots(3, 1, constrained_layout=True)
axs[0].plot(t, x)
axs[0].set_title('cos(w0*t+theta)')
# abs(c) * exp(r * t)
c = 2;
r = 1;
x = np.abs(c) * np.exp(r * t)
axs[1].plot(t, x)
axs[1].set_title('abs(c) * exp(r * t)')
# cos(w0*t+theta)*abs(c) * exp(r * t)
x = np.cos(w0*t+theta)*np.abs(c) * np.exp(r * t)
axs[2].plot(t, x)
axs[2].set_title('cos(w0*t+theta)*abs(c) * exp(r * t)')
plt.show()

n = np.linspace(-5, 5, 11)
# cos(w0*n+theta)
w0 = pi/3
theta = pi/4
x = np.cos(w0*n+theta)
fig, axs = plt.subplots(3, 1, constrained_layout=True)
axs[0].stem(n, x)
axs[0].set_title('cos(w0*n+theta)')
# abs(c) * exp(r * n)
c = 2;
r = 1;
x = np.abs(c) * np.exp(r * n)
axs[1].stem(n, x)
axs[1].set_title('abs(c) * exp(r * n)')
# cos(w0*n+theta)*abs(c) * exp(r * n)
x = np.cos(w0*n+theta)*np.abs(c) * np.exp(r * n)
axs[2].stem(n, x)
axs[2].set_title('cos(w0*n+theta)*abs(c) * exp(r * n)')
plt.show()
