#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt

pi = np.pi
t = np.linspace(-5, 5)
x = 3 * np.sin(pi * t) + 3 * np.abs(np.cos(7 * t))
y = []
for i in x:
    if i > 5:
        y.append(5)
    elif i < 0:
        y.append(0)
    else:
        y.append(i)
fig, axs = plt.subplots(2, 1, constrained_layout=True)
axs[0].plot(t, x)
axs[0].set_title('x(t)')
axs[1].plot(t, y)
axs[1].set_title('y(t)')
plt.show()
